<?php 
header("location:/pages/sign_in-admin.php");
 ?>