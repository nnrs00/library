<?php  
$server = "localhost";
$uname = "root";
$password = "";
$database_name = "systemdb";
$db = mysqli_connect($server, $uname, $password, $database_name);
// if($db == false){
// 	die("Error: connection error." .mysqli_connect_error());
// }
?>
